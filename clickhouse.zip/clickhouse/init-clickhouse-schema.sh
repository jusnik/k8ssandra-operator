#!/usr/bin/env bash
###############################################################################
# init-clickhouse-schema.sh
#
# Initializes the ClickHouse schema for the DPIP central analytics database.
# Waits for ClickHouse to be healthy and ready, then runs the SQL init files
# from dpip-center/init/clickhouse/ in alphabetical order.
#
# Features:
#   - Waits for ClickHouse to be reachable (HTTP /ping) with a timeout.
#   - Validates authentication works before running any SQL.
#   - Checks if the database/tables already exist (idempotent -- safe to re-run).
#   - Runs each SQL file and reports success/failure per file.
#   - Verifies all expected tables and materialized views exist at the end.
#   - Exits non-zero on any failure.
#
# Usage:
#   ./init-clickhouse-schema.sh
#
# Environment variables (override as needed):
#   CLICKHOUSE_HOST        - ClickHouse host (default: localhost)
#   CLICKHOUSE_PORT        - ClickHouse HTTP port (default: 8123)
#   CLICKHOUSE_TCP_PORT    - ClickHouse Native TCP port (default: 9000)
#   CLICKHOUSE_USER        - ClickHouse user (default: default)
#   CLICKHOUSE_PASSWORD    - ClickHouse password (default: clickhouse)
#   CLICKHOUSE_DATABASE    - Target database (default: central_analytics)
#   SQL_DIR                - Directory containing SQL files
#                            (default: ./dpip-center/init/clickhouse)
#   MAX_WAIT_SECONDS       - Max seconds to wait for ClickHouse to be ready
#                            (default: 120)
#   KUBECTL_NS             - Kubernetes namespace (if using kubectl exec)
#                            (default: clickhouse)
#   USE_KUBECTL            - If set to "1", use kubectl exec to run SQL
#                            inside the ClickHouse pod instead of connecting
#                            over the network (default: 0)
#   KUBECTL_POD            - Pod name when USE_KUBECTL=1
#                            (default: clickhouse-0)
#
# Examples:
#   # Local connection (default)
#   ./init-clickhouse-schema.sh
#
#   # Remote connection
#   CLICKHOUSE_HOST=10.0.0.5 CLICKHOUSE_PASSWORD=secret ./init-clickhouse-schema.sh
#
#   # Via kubectl exec (no network access to pod, run from workstation)
#   USE_KUBECTL=1 KUBECTL_POD=clickhouse-0 ./init-clickhouse-schema.sh
#
#   # From within the cluster (e.g., a Job)
#   CLICKHOUSE_HOST=clickhouse.clickhouse.svc.cluster.local ./init-clickhouse-schema.sh
#
###############################################################################
set -euo pipefail

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
CLICKHOUSE_HOST="${CLICKHOUSE_HOST:-localhost}"
CLICKHOUSE_PORT="${CLICKHOUSE_PORT:-8123}"
CLICKHOUSE_TCP_PORT="${CLICKHOUSE_TCP_PORT:-9000}"
CLICKHOUSE_USER="${CLICKHOUSE_USER:-default}"
CLICKHOUSE_PASSWORD="${CLICKHOUSE_PASSWORD:-clickhouse}"
CLICKHOUSE_DATABASE="${CLICKHOUSE_DATABASE:-central_analytics}"

# Resolve SQL directory relative to this script's location
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SQL_DIR="${SQL_DIR:-${SCRIPT_DIR}/dpip-center/init/clickhouse}"

MAX_WAIT_SECONDS="${MAX_WAIT_SECONDS:-120}"
USE_KUBECTL="${USE_KUBECTL:-0}"
KUBECTL_NS="${KUBECTL_NS:-clickhouse}"
KUBECTL_POD="${KUBECTL_POD:-clickhouse-0}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Counters
TOTAL_FILES=0
SUCCESS_FILES=0
FAILED_FILES=0

# Expected tables and views after initialization
EXPECTED_TABLES=(
  "feedback"
  "check_log"
  "failure"
  "feedback_decision_by_reason"
  "check_daily_outcomes"
  "failure_daily_outcomes"
)

EXPECTED_VIEWS=(
  "mv_feedback_decision_by_reason"
  "mv_check_daily_outcomes"
  "mv_failure_daily_outcomes"
)

# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------
log_info() {
  echo -e "${BLUE}[INFO]${NC} $*"
}

log_ok() {
  echo -e "${GREEN}[OK]${NC} $*"
}

log_warn() {
  echo -e "${YELLOW}[WARN]${NC} $*"
}

log_error() {
  echo -e "${RED}[ERROR]${NC} $*" >&2
}

# Run a SQL query against ClickHouse.
# Uses HTTP interface by default, or kubectl exec if USE_KUBECTL=1.
# Args: $1 = SQL string, $2 = optional flag "--multiquery"
run_sql() {
  local sql="$1"
  shift
  local extra_flags="$*"

  if [[ "${USE_KUBECTL}" == "1" ]]; then
    kubectl exec -n "${KUBECTL_NS}" "${KUBECTL_POD}" -- \
      clickhouse-client \
        --user "${CLICKHOUSE_USER}" \
        --password "${CLICKHOUSE_PASSWORD}" \
        --database "${CLICKHOUSE_DATABASE}" \
        ${extra_flags} \
        --query "${sql}"
  else
    curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/" \
      -u "${CLICKHOUSE_USER}:${CLICKHOUSE_PASSWORD}" \
      --data-binary "${sql}"
  fi
}

# Run a SQL file against ClickHouse.
# Args: $1 = path to SQL file
run_sql_file() {
  local sql_file="$1"
  local filename
  filename="$(basename "${sql_file}")"

  if [[ "${USE_KUBECTL}" == "1" ]]; then
    # Copy SQL file into the pod, run it, then remove it
    kubectl cp "${sql_file}" "${KUBECTL_NS}/${KUBECTL_POD}:/tmp/${filename}"
    kubectl exec -n "${KUBECTL_NS}" "${KUBECTL_POD}" -- \
      clickhouse-client \
        --user "${CLICKHOUSE_USER}" \
        --password "${CLICKHOUSE_PASSWORD}" \
        --multiquery \
        < /dev/null \
        --queries-file "/tmp/${filename}"
    kubectl exec -n "${KUBECTL_NS}" "${KUBECTL_POD}" -- rm -f "/tmp/${filename}"
  else
    curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/" \
      -u "${CLICKHOUSE_USER}:${CLICKHOUSE_PASSWORD}" \
      --data-binary @"${sql_file}"
  fi
}

# Check if ClickHouse HTTP /ping responds with 200
check_ping() {
  if [[ "${USE_KUBECTL}" == "1" ]]; then
    kubectl exec -n "${KUBECTL_NS}" "${KUBECTL_POD}" -- \
      clickhouse-client --user "${CLICKHOUSE_USER}" --password "${CLICKHOUSE_PASSWORD}" \
      --query "SELECT 1" >/dev/null 2>&1
  else
    curl -sS -o /dev/null -w "%{http_code}" \
      "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/ping" 2>/dev/null | grep -q "200"
  fi
}

# ---------------------------------------------------------------------------
# Pre-flight checks
# ---------------------------------------------------------------------------
log_info "=== ClickHouse Schema Initialization ==="
echo ""
log_info "Configuration:"
log_info "  Host:      ${CLICKHOUSE_HOST}"
log_info "  HTTP port: ${CLICKHOUSE_PORT}"
log_info "  TCP port:  ${CLICKHOUSE_TCP_PORT}"
log_info "  User:      ${CLICKHOUSE_USER}"
log_info "  Database:  ${CLICKHOUSE_DATABASE}"
log_info "  SQL dir:   ${SQL_DIR}"
log_info "  Use kubectl: ${USE_KUBECTL}"
if [[ "${USE_KUBECTL}" == "1" ]]; then
  log_info "  Namespace: ${KUBECTL_NS}"
  log_info "  Pod:       ${KUBECTL_POD}"
fi
echo ""

# Check if SQL directory exists
if [[ ! -d "${SQL_DIR}" ]]; then
  log_error "SQL directory not found: ${SQL_DIR}"
  log_error "Expected to find SQL files in dpip-center/init/clickhouse/"
  log_error "Run this script from the repository root (RBI/ directory)."
  exit 1
fi

# Count SQL files
SQL_FILES=( "$(ls -1 "${SQL_DIR}"/*.sql 2>/dev/null)" )
# shellcheck disable=SC2012
mapfile -t SQL_FILES < <(ls -1 "${SQL_DIR}"/*.sql 2>/dev/null | sort)
TOTAL_FILES=${#SQL_FILES[@]}

if [[ ${TOTAL_FILES} -eq 0 ]]; then
  log_error "No .sql files found in ${SQL_DIR}"
  exit 1
fi

log_info "Found ${TOTAL_FILES} SQL file(s) to execute:"
for f in "${SQL_FILES[@]}"; do
  log_info "  - $(basename "${f}")"
done
echo ""

# ---------------------------------------------------------------------------
# Wait for ClickHouse to be ready
# ---------------------------------------------------------------------------
log_info "Waiting for ClickHouse to be ready (max ${MAX_WAIT_SECONDS}s)..."

WAIT=0
while [[ ${WAIT} -lt ${MAX_WAIT_SECONDS} ]]; do
  if check_ping; then
    log_ok "ClickHouse is responding (after ${WAIT}s)"
    break
  fi
  WAIT=$((WAIT + 2))
  sleep 2
  if [[ $((WAIT % 10)) -eq 0 ]]; then
    log_info "Still waiting... (${WAIT}s elapsed)"
  fi
done

if [[ ${WAIT} -ge ${MAX_WAIT_SECONDS} ]]; then
  log_error "ClickHouse did not become ready within ${MAX_WAIT_SECONDS} seconds"
  log_error "Check that the ClickHouse pod is running and healthy:"
  if [[ "${USE_KUBECTL}" == "1" ]]; then
    log_error "  kubectl -n ${KUBECTL_NS} get pods"
    log_error "  kubectl -n ${KUBECTL_NS} logs ${KUBECTL_POD}"
  else
    log_error "  Verify ${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT} is reachable"
  fi
  exit 1
fi

# ---------------------------------------------------------------------------
# Validate authentication
# ---------------------------------------------------------------------------
log_info "Validating authentication..."
AUTH_RESULT=$(run_sql "SELECT currentUser()" 2>&1) || true

if [[ "${AUTH_RESULT}" != "${CLICKHOUSE_USER}" ]]; then
  log_error "Authentication failed. Expected user '${CLICKHOUSE_USER}', got: '${AUTH_RESULT}'"
  log_error "Check CLICKHOUSE_USER and CLICKHOUSE_PASSWORD environment variables."
  exit 1
fi
log_ok "Authentication successful (user: ${AUTH_RESULT})"
echo ""

# ---------------------------------------------------------------------------
# Check ClickHouse version (must be >= 22.8 for refreshable MVs)
# ---------------------------------------------------------------------------
log_info "Checking ClickHouse version..."
CH_VERSION=$(run_sql "SELECT version()" 2>&1) || true
log_info "ClickHouse version: ${CH_VERSION}"

# Extract major.minor for comparison
CH_MAJOR=$(echo "${CH_VERSION}" | cut -d. -f1)
CH_MINOR=$(echo "${CH_VERSION}" | cut -d. -f2)

if [[ ${CH_MAJOR} -lt 22 ]] || ([[ ${CH_MAJOR} -eq 22 ]] && [[ ${CH_MINOR} -lt 8 ]]); then
  log_error "ClickHouse version ${CH_VERSION} is too old. Need >= 22.8 for refreshable materialized views."
  exit 1
fi
log_ok "Version ${CH_VERSION} supports refreshable materialized views"
echo ""

# ---------------------------------------------------------------------------
# Check if database already exists
# ---------------------------------------------------------------------------
log_info "Checking if database '${CLICKHOUSE_DATABASE}' already exists..."
DB_EXISTS=$(run_sql "SELECT count() FROM system.databases WHERE name = '${CLICKHOUSE_DATABASE}'" 2>&1) || true

if [[ "${DB_EXISTS}" == "1" ]]; then
  log_warn "Database '${CLICKHOUSE_DATABASE}' already exists"
  # Check if any tables exist
  EXISTING_TABLES=$(run_sql "SELECT groupArray(name) FROM system.tables WHERE database = '${CLICKHOUSE_DATABASE}'" 2>&1) || true
  log_warn "Existing tables: ${EXISTING_TABLES}"
  log_info "Schema init is idempotent (uses IF NOT EXISTS). Proceeding..."
else
  log_info "Database '${CLICKHOUSE_DATABASE}' does not exist yet. It will be created by the first SQL file."
fi
echo ""

# ---------------------------------------------------------------------------
# Execute SQL files
# ---------------------------------------------------------------------------
log_info "Executing SQL files..."
echo ""

for sql_file in "${SQL_FILES[@]}"; do
  filename="$(basename "${sql_file}")"
  log_info "Running: ${filename}"

  if run_sql_file "${sql_file}" 2>&1; then
    log_ok "  ${filename} -- succeeded"
    SUCCESS_FILES=$((SUCCESS_FILES + 1))
  else
    log_error "  ${filename} -- FAILED"
    FAILED_FILES=$((FAILED_FILES + 1))
    # Continue with remaining files -- some may not depend on the failed one
    # (e.g., if 001 fails, 003 might still work). We'll verify at the end.
  fi
  echo ""
done

# ---------------------------------------------------------------------------
# Verify all expected tables exist
# ---------------------------------------------------------------------------
log_info "=== Verification ==="
echo ""

VERIFICATION_FAILED=0

log_info "Checking tables in database '${CLICKHOUSE_DATABASE}'..."
for table in "${EXPECTED_TABLES[@]}"; do
  EXISTS=$(run_sql "SELECT count() FROM system.tables WHERE database = '${CLICKHOUSE_DATABASE}' AND name = '${table}'" 2>&1) || true
  if [[ "${EXISTS}" == "1" ]]; then
    log_ok "  Table: ${table}"
  else
    log_error "  Table: ${table} -- MISSING"
    VERIFICATION_FAILED=1
  fi
done

echo ""
log_info "Checking materialized views..."
for view in "${EXPECTED_VIEWS[@]}"; do
  EXISTS=$(run_sql "SELECT count() FROM system.tables WHERE database = '${CLICKHOUSE_DATABASE}' AND name = '${view}' AND engine = 'View'" 2>&1) || true
  if [[ "${EXISTS}" == "1" ]]; then
    log_ok "  View: ${view}"
  else
    # Also check as RefreshableMaterializedView engine
    EXISTS=$(run_sql "SELECT count() FROM system.tables WHERE database = '${CLICKHOUSE_DATABASE}' AND name = '${view}'" 2>&1) || true
    if [[ "${EXISTS}" == "1" ]]; then
      log_ok "  View: ${view}"
    else
      log_error "  View: ${view} -- MISSING"
      VERIFICATION_FAILED=1
    fi
  fi
done

echo ""

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
log_info "=== Summary ==="
log_info "  Total SQL files:  ${TOTAL_FILES}"
log_ok "  Succeeded:        ${SUCCESS_FILES}"
if [[ ${FAILED_FILES} -gt 0 ]]; then
  log_error "  Failed:           ${FAILED_FILES}"
else
  log_info "  Failed:           ${FAILED_FILES}"
fi
echo ""

if [[ ${VERIFICATION_FAILED} -eq 1 ]]; then
  log_error "Schema verification FAILED -- some tables or views are missing."
  log_error "Check the output above for details."
  exit 1
fi

if [[ ${FAILED_FILES} -gt 0 ]]; then
  log_warn "Some SQL files failed, but all expected tables/views are present."
  log_warn "This may be OK if the tables already existed from a previous run."
  exit 0
fi

log_ok "All SQL files executed successfully and all expected tables/views verified."
log_ok "ClickHouse schema initialization complete."
exit 0
