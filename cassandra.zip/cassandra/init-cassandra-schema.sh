#!/usr/bin/env bash
###############################################################################
# init-cassandra-schema.sh
#
# Initializes the Cassandra schema for the DPIP feedback mappings database.
# Waits for Cassandra to be healthy and ready, then runs the CQL init files
# from dpip-center/init/cassandra/ in alphabetical order.
#
# Features:
#   - Waits for Cassandra to be reachable (cqlsh DESCRIBE CLUSTER) with timeout.
#   - Validates authentication works before running any CQL.
#   - Checks if the keyspace/tables already exist (idempotent -- safe to re-run).
#   - Runs each CQL file and reports success/failure per file.
#   - Verifies all expected tables exist at the end.
#   - Exits non-zero on any failure.
#
# Usage:
#   ./init-cassandra-schema.sh
#
# Environment variables (override as needed):
#   CASSANDRA_HOST          - Cassandra host (default: localhost)
#   CASSANDRA_PORT          - Cassandra CQL port (default: 9042)
#   CASSANDRA_USER          - Cassandra user (default: cassandra)
#   CASSANDRA_PASSWORD      - Cassandra password (default: cassandra)
#   CQL_DIR                 - Directory containing CQL files
#                             (default: ./dpip-center/init/cassandra)
#   KEYSPACE                - Target keyspace (default: feedback_keyspace)
#   MAX_WAIT_SECONDS        - Max seconds to wait for Cassandra (default: 180)
#   USE_KUBECTL             - If "1", use kubectl exec to run CQL inside the
#                             Cassandra pod instead of connecting over network
#                             (default: 0)
#   KUBECTL_NS              - Kubernetes namespace (default: cassandra)
#   KUBECTL_POD             - Pod name when USE_KUBECTL=1 (default: cassandra-0)
#
# Examples:
#   # Local connection
#   ./init-cassandra-schema.sh
#
#   # Remote connection
#   CASSANDRA_HOST=10.0.0.5 CASSANDRA_PASSWORD=secret ./init-cassandra-schema.sh
#
#   # Via kubectl exec
#   USE_KUBECTL=1 KUBECTL_POD=cassandra-0 ./init-cassandra-schema.sh
#
###############################################################################
set -euo pipefail

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
CASSANDRA_HOST="${CASSANDRA_HOST:-localhost}"
CASSANDRA_PORT="${CASSANDRA_PORT:-9042}"
CASSANDRA_USER="${CASSANDRA_USER:-cassandra}"
CASSANDRA_PASSWORD="${CASSANDRA_PASSWORD:-cassandra}"
KEYSPACE="${KEYSPACE:-feedback_keyspace}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CQL_DIR="${CQL_DIR:-${SCRIPT_DIR}/dpip-center/init/cassandra}"

MAX_WAIT_SECONDS="${MAX_WAIT_SECONDS:-180}"
USE_KUBECTL="${USE_KUBECTL:-0}"
KUBECTL_NS="${KUBECTL_NS:-cassandra}"
KUBECTL_POD="${KUBECTL_POD:-cassandra-0}"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Counters
TOTAL_FILES=0
SUCCESS_FILES=0
FAILED_FILES=0

# Expected tables after initialization
EXPECTED_TABLES=(
  "feedback_file_mappings"
)

# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------
log_info()  { echo -e "${BLUE}[INFO]${NC} $*"; }
log_ok()    { echo -e "${GREEN}[OK]${NC} $*"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }

# Run a CQL query against Cassandra
run_cql() {
  local cql="$1"

  if [[ "${USE_KUBECTL}" == "1" ]]; then
    kubectl exec -n "${KUBECTL_NS}" "${KUBECTL_POD}" -- \
      cqlsh -u "${CASSANDRA_USER}" -p "${CASSANDRA_PASSWORD}" \
        -e "${cql}" 2>&1
  else
    cqlsh "${CASSANDRA_HOST}" "${CASSANDRA_PORT}" \
      -u "${CASSANDRA_USER}" -p "${CASSANDRA_PASSWORD}" \
      -e "${cql}" 2>&1
  fi
}

# Run a CQL file against Cassandra
run_cql_file() {
  local cql_file="$1"

  if [[ "${USE_KUBECTL}" == "1" ]]; then
    kubectl exec -n "${KUBECTL_NS}" -i "${KUBECTL_POD}" -- \
      cqlsh -u "${CASSANDRA_USER}" -p "${CASSANDRA_PASSWORD}" \
        -f /dev/stdin < "${cql_file}" 2>&1
  else
    cqlsh "${CASSANDRA_HOST}" "${CASSANDRA_PORT}" \
      -u "${CASSANDRA_USER}" -p "${CASSANDRA_PASSWORD}" \
      -f "${cql_file}" 2>&1
  fi
}

# Check if Cassandra is responding
check_cassandra() {
  if [[ "${USE_KUBECTL}" == "1" ]]; then
    kubectl exec -n "${KUBECTL_NS}" "${KUBECTL_POD}" -- \
      cqlsh -u "${CASSANDRA_USER}" -p "${CASSANDRA_PASSWORD}" \
        -e "DESCRIBE CLUSTER" >/dev/null 2>&1
  else
    cqlsh "${CASSANDRA_HOST}" "${CASSANDRA_PORT}" \
      -u "${CASSANDRA_USER}" -p "${CASSANDRA_PASSWORD}" \
      -e "DESCRIBE CLUSTER" >/dev/null 2>&1
  fi
}

# ---------------------------------------------------------------------------
# Pre-flight checks
# ---------------------------------------------------------------------------
log_info "=== Cassandra Schema Initialization ==="
echo ""
log_info "Configuration:"
log_info "  Host:      ${CASSANDRA_HOST}"
log_info "  CQL port:  ${CASSANDRA_PORT}"
log_info "  User:      ${CASSANDRA_USER}"
log_info "  Keyspace:  ${KEYSPACE}"
log_info "  CQL dir:   ${CQL_DIR}"
log_info "  Use kubectl: ${USE_KUBECTL}"
if [[ "${USE_KUBECTL}" == "1" ]]; then
  log_info "  Namespace: ${KUBECTL_NS}"
  log_info "  Pod:       ${KUBECTL_POD}"
fi
echo ""

# Check if CQL directory exists
if [[ ! -d "${CQL_DIR}" ]]; then
  log_error "CQL directory not found: ${CQL_DIR}"
  log_error "Expected to find CQL files in dpip-center/init/cassandra/"
  log_error "Run this script from the repository root (RBI/ directory)."
  exit 1
fi

# Count CQL files
mapfile -t CQL_FILES < <(ls -1 "${CQL_DIR}"/*.cql 2>/dev/null | sort)
TOTAL_FILES=${#CQL_FILES[@]}

if [[ ${TOTAL_FILES} -eq 0 ]]; then
  log_error "No .cql files found in ${CQL_DIR}"
  exit 1
fi

log_info "Found ${TOTAL_FILES} CQL file(s) to execute:"
for f in "${CQL_FILES[@]}"; do
  log_info "  - $(basename "${f}")"
done
echo ""

# ---------------------------------------------------------------------------
# Wait for Cassandra to be ready
# ---------------------------------------------------------------------------
log_info "Waiting for Cassandra to be ready (max ${MAX_WAIT_SECONDS}s)..."
log_info "Note: Cassandra can take 60-120s to start on first boot."

WAIT=0
while [[ ${WAIT} -lt ${MAX_WAIT_SECONDS} ]]; do
  if check_cassandra; then
    log_ok "Cassandra is responding (after ${WAIT}s)"
    break
  fi
  WAIT=$((WAIT + 5))
  sleep 5
  if [[ $((WAIT % 15)) -eq 0 ]]; then
    log_info "Still waiting... (${WAIT}s elapsed)"
  fi
done

if [[ ${WAIT} -ge ${MAX_WAIT_SECONDS} ]]; then
  log_error "Cassandra did not become ready within ${MAX_WAIT_SECONDS} seconds"
  log_error "Check that the Cassandra pod is running and healthy:"
  if [[ "${USE_KUBECTL}" == "1" ]]; then
    log_error "  kubectl -n ${KUBECTL_NS} get pods"
    log_error "  kubectl -n ${KUBECTL_NS} logs ${KUBECTL_POD}"
  else
    log_error "  Verify ${CASSANDRA_HOST}:${CASSANDRA_PORT} is reachable"
  fi
  exit 1
fi

# ---------------------------------------------------------------------------
# Validate authentication and get cluster info
# ---------------------------------------------------------------------------
log_info "Validating authentication..."
CLUSTER_INFO=$(run_cql "DESCRIBE CLUSTER" 2>&1) || true

if echo "${CLUSTER_INFO}" | grep -qi "Cluster:"; then
  log_ok "Authentication successful"
  echo "${CLUSTER_INFO}" | head -5 | while read -r line; do
    log_info "  ${line}"
  done
else
  log_error "Authentication or connection failed:"
  log_error "  ${CLUSTER_INFO}"
  log_error "Check CASSANDRA_USER and CASSANDRA_PASSWORD environment variables."
  exit 1
fi
echo ""

# ---------------------------------------------------------------------------
# Check Cassandra version
# ---------------------------------------------------------------------------
log_info "Checking Cassandra version..."
CH_VERSION=$(run_cql "SELECT release_version FROM system.local;" 2>&1 | tail -1 | tr -d '[:space:]') || true
log_info "Cassandra version: ${CH_VERSION}"

if [[ -z "${CH_VERSION}" ]] || [[ "${CH_VERSION}" == "release_version" ]]; then
  log_warn "Could not determine Cassandra version, continuing anyway..."
else
  log_ok "Cassandra version: ${CH_VERSION}"
fi
echo ""

# ---------------------------------------------------------------------------
# Check if keyspace already exists
# ---------------------------------------------------------------------------
log_info "Checking if keyspace '${KEYSPACE}' already exists..."
KS_EXISTS=$(run_cql "SELECT keyspace_name FROM system_schema.keyspaces WHERE keyspace_name = '${KEYSPACE}';" 2>&1 | grep -c "${KEYSPACE}" || true)

if [[ "${KS_EXISTS}" -ge 1 ]]; then
  log_warn "Keyspace '${KEYSPACE}' already exists"
  EXISTING_TABLES=$(run_cql "SELECT table_name FROM system_schema.tables WHERE keyspace_name = '${KEYSPACE}';" 2>&1) || true
  log_warn "Existing tables: ${EXISTING_TABLES}"
  log_info "Schema init is idempotent (uses IF NOT EXISTS). Proceeding..."
else
  log_info "Keyspace '${KEYSPACE}' does not exist yet. It will be created by the first CQL file."
fi
echo ""

# ---------------------------------------------------------------------------
# Execute CQL files
# ---------------------------------------------------------------------------
log_info "Executing CQL files..."
echo ""

for cql_file in "${CQL_FILES[@]}"; do
  filename="$(basename "${cql_file}")"
  log_info "Running: ${filename}"

  if run_cql_file "${cql_file}"; then
    log_ok "  ${filename} -- succeeded"
    SUCCESS_FILES=$((SUCCESS_FILES + 1))
  else
    log_error "  ${filename} -- FAILED"
    FAILED_FILES=$((FAILED_FILES + 1))
  fi
  echo ""
done

# ---------------------------------------------------------------------------
# Verify all expected tables exist
# ---------------------------------------------------------------------------
log_info "=== Verification ==="
echo ""

VERIFICATION_FAILED=0

log_info "Checking tables in keyspace '${KEYSPACE}'..."
for table in "${EXPECTED_TABLES[@]}"; do
  EXISTS=$(run_cql "SELECT table_name FROM system_schema.tables WHERE keyspace_name = '${KEYSPACE}' AND table_name = '${table}';" 2>&1 | grep -c "${table}" || true)
  if [[ "${EXISTS}" -ge 1 ]]; then
    log_ok "  Table: ${table}"
  else
    log_error "  Table: ${table} -- MISSING"
    VERIFICATION_FAILED=1
  fi
done

echo ""

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
log_info "=== Summary ==="
log_info "  Total CQL files:  ${TOTAL_FILES}"
log_ok "  Succeeded:         ${SUCCESS_FILES}"
if [[ ${FAILED_FILES} -gt 0 ]]; then
  log_error "  Failed:            ${FAILED_FILES}"
else
  log_info "  Failed:            ${FAILED_FILES}"
fi
echo ""

if [[ ${VERIFICATION_FAILED} -eq 1 ]]; then
  log_error "Schema verification FAILED -- some tables are missing."
  log_error "Check the output above for details."
  exit 1
fi

if [[ ${FAILED_FILES} -gt 0 ]]; then
  log_warn "Some CQL files failed, but all expected tables are present."
  log_warn "This may be OK if the tables already existed from a previous run."
  exit 0
fi

log_ok "All CQL files executed successfully and all expected tables verified."
log_ok "Cassandra schema initialization complete."
exit 0
